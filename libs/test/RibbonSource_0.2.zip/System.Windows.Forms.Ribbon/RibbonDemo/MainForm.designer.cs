namespace RibbonDemo
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ribbon1 = new System.Windows.Forms.Ribbon();
            this.ribbonTab1 = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel1 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton1 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator1 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton73 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton74 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator2 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton75 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator3 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton76 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton77 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton87 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton2 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton3 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton4 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel2 = new System.Windows.Forms.RibbonPanel();
            this.ribbonItemGroup1 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton5 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton6 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup2 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton7 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup3 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton8 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton9 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton10 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton14 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup4 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton11 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton12 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton13 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup5 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonColorChooser1 = new System.Windows.Forms.RibbonColorChooser();
            this.ribbonColorChooser2 = new System.Windows.Forms.RibbonColorChooser();
            this.ribbonItemGroup13 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonComboBox2 = new System.Windows.Forms.RibbonComboBox();
            this.ribbonSeparator7 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton15 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton16 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator8 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton94 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton95 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton96 = new System.Windows.Forms.RibbonButton();
            this.ribbonComboBox3 = new System.Windows.Forms.RibbonComboBox();
            this.ribbonButton97 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton98 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton99 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton100 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton101 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton102 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton103 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton104 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton105 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton106 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton107 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel3 = new System.Windows.Forms.RibbonPanel();
            this.ribbonItemGroup6 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton17 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton18 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton19 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup7 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton20 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton21 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton22 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton23 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup8 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton24 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup9 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton25 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton26 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup10 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton27 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup11 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton28 = new System.Windows.Forms.RibbonButton();
            this.ribbonItemGroup12 = new System.Windows.Forms.RibbonItemGroup();
            this.ribbonButton29 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton30 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel4 = new System.Windows.Forms.RibbonPanel();
            this.lst = new System.Windows.Forms.RibbonButtonList();
            this.ribbonButton34 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator5 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton80 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton84 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton85 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton86 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton81 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton82 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator4 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton83 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel5 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton31 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton78 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton79 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton32 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton33 = new System.Windows.Forms.RibbonButton();
            this.ribbonTab2 = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel6 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton37 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton38 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton39 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel7 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton40 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel8 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton41 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton42 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton43 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton44 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton45 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel9 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton46 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton47 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel10 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton48 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton70 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton71 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton72 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton49 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton50 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel11 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton51 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton52 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton53 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton54 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton55 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton56 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton57 = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel12 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButton35 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton36 = new System.Windows.Forms.RibbonButton();
            this.ribbonTab3 = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel13 = new System.Windows.Forms.RibbonPanel();
            this.ribbonTextBox2 = new System.Windows.Forms.RibbonTextBox();
            this.ribbonSeparator6 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonTextBox3 = new System.Windows.Forms.RibbonTextBox();
            this.ribbonTextBox4 = new System.Windows.Forms.RibbonTextBox();
            this.ribbonPanel14 = new System.Windows.Forms.RibbonPanel();
            this.ribbonTextBox5 = new System.Windows.Forms.RibbonTextBox();
            this.ribbonComboBox1 = new System.Windows.Forms.RibbonComboBox();
            this.ribbonButton91 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton92 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton93 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton69 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton68 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton67 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton66 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton65 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton64 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton63 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton62 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton61 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton60 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton59 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton58 = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonList1 = new System.Windows.Forms.RibbonButtonList();
            this.ribbonButton88 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton89 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton90 = new System.Windows.Forms.RibbonButton();
            this.SuspendLayout();
            // 
            // ribbon1
            // 
            this.ribbon1.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.Minimized = false;
            this.ribbon1.Name = "ribbon1";
            this.ribbon1.Size = new System.Drawing.Size(796, 115);
            this.ribbon1.TabIndex = 0;
            this.ribbon1.Tabs.Add(this.ribbonTab1);
            this.ribbon1.Tabs.Add(this.ribbonTab2);
            this.ribbon1.Tabs.Add(this.ribbonTab3);
            this.ribbon1.TabSpacing = 6;
            // 
            // ribbonTab1
            // 
            this.ribbonTab1.Panels.Add(this.ribbonPanel1);
            this.ribbonTab1.Panels.Add(this.ribbonPanel2);
            this.ribbonTab1.Panels.Add(this.ribbonPanel3);
            this.ribbonTab1.Panels.Add(this.ribbonPanel4);
            this.ribbonTab1.Panels.Add(this.ribbonPanel5);
            this.ribbonTab1.Tag = null;
            this.ribbonTab1.Text = "Home";
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.ButtonMoreEnabled = false;
            this.ribbonPanel1.Image = global::RibbonDemo.Properties.Resources.paste16;
            this.ribbonPanel1.Items.Add(this.ribbonButton1);
            this.ribbonPanel1.Items.Add(this.ribbonButton2);
            this.ribbonPanel1.Items.Add(this.ribbonButton3);
            this.ribbonPanel1.Items.Add(this.ribbonButton4);
            this.ribbonPanel1.Tag = null;
            this.ribbonPanel1.Text = "Clipboard";
            // 
            // ribbonButton1
            // 
            this.ribbonButton1.AltKey = null;
            this.ribbonButton1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton1.DropDownItems.Add(this.ribbonSeparator1);
            this.ribbonButton1.DropDownItems.Add(this.ribbonButton73);
            this.ribbonButton1.DropDownItems.Add(this.ribbonButton74);
            this.ribbonButton1.DropDownItems.Add(this.ribbonSeparator2);
            this.ribbonButton1.DropDownItems.Add(this.ribbonButton75);
            this.ribbonButton1.DropDownItems.Add(this.ribbonSeparator3);
            this.ribbonButton1.DropDownItems.Add(this.ribbonButton76);
            this.ribbonButton1.DropDownItems.Add(this.ribbonButton77);
            this.ribbonButton1.DropDownItems.Add(this.ribbonButton87);
            this.ribbonButton1.DropDownResizable = true;
            this.ribbonButton1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.Image")));
            this.ribbonButton1.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.SmallImage")));
            this.ribbonButton1.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton1.Tag = null;
            this.ribbonButton1.Text = "Paste";
            this.ribbonButton1.ToolTip = null;
            this.ribbonButton1.ToolTipImage = null;
            this.ribbonButton1.ToolTipTitle = null;
            // 
            // ribbonSeparator1
            // 
            this.ribbonSeparator1.AltKey = null;
            this.ribbonSeparator1.Image = null;
            this.ribbonSeparator1.Tag = null;
            this.ribbonSeparator1.Text = "Paste options";
            this.ribbonSeparator1.ToolTip = null;
            this.ribbonSeparator1.ToolTipImage = null;
            this.ribbonSeparator1.ToolTipTitle = null;
            // 
            // ribbonButton73
            // 
            this.ribbonButton73.AltKey = null;
            this.ribbonButton73.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton73.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton73.Image")));
            this.ribbonButton73.SmallImage = global::RibbonDemo.Properties.Resources.paste16;
            this.ribbonButton73.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton73.Tag = null;
            this.ribbonButton73.Text = "Paste";
            this.ribbonButton73.ToolTip = null;
            this.ribbonButton73.ToolTipImage = null;
            this.ribbonButton73.ToolTipTitle = null;
            // 
            // ribbonButton74
            // 
            this.ribbonButton74.AltKey = null;
            this.ribbonButton74.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton74.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton74.Image")));
            this.ribbonButton74.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton74.SmallImage")));
            this.ribbonButton74.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton74.Tag = null;
            this.ribbonButton74.Text = "Paste special...";
            this.ribbonButton74.ToolTip = null;
            this.ribbonButton74.ToolTipImage = null;
            this.ribbonButton74.ToolTipTitle = null;
            // 
            // ribbonSeparator2
            // 
            this.ribbonSeparator2.AltKey = null;
            this.ribbonSeparator2.Image = null;
            this.ribbonSeparator2.Tag = null;
            this.ribbonSeparator2.Text = null;
            this.ribbonSeparator2.ToolTip = null;
            this.ribbonSeparator2.ToolTipImage = null;
            this.ribbonSeparator2.ToolTipTitle = null;
            // 
            // ribbonButton75
            // 
            this.ribbonButton75.AltKey = null;
            this.ribbonButton75.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton75.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton75.Image")));
            this.ribbonButton75.SmallImage = global::RibbonDemo.Properties.Resources.link16;
            this.ribbonButton75.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton75.Tag = null;
            this.ribbonButton75.Text = "Paste link";
            this.ribbonButton75.ToolTip = null;
            this.ribbonButton75.ToolTipImage = null;
            this.ribbonButton75.ToolTipTitle = null;
            // 
            // ribbonSeparator3
            // 
            this.ribbonSeparator3.AltKey = null;
            this.ribbonSeparator3.Image = null;
            this.ribbonSeparator3.Tag = null;
            this.ribbonSeparator3.Text = "Clipboard options";
            this.ribbonSeparator3.ToolTip = null;
            this.ribbonSeparator3.ToolTipImage = null;
            this.ribbonSeparator3.ToolTipTitle = null;
            // 
            // ribbonButton76
            // 
            this.ribbonButton76.AltKey = null;
            this.ribbonButton76.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton76.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton76.Image")));
            this.ribbonButton76.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton76.SmallImage")));
            this.ribbonButton76.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton76.Tag = null;
            this.ribbonButton76.Text = "Clear clipboard";
            this.ribbonButton76.ToolTip = null;
            this.ribbonButton76.ToolTipImage = null;
            this.ribbonButton76.ToolTipTitle = null;
            // 
            // ribbonButton77
            // 
            this.ribbonButton77.AltKey = null;
            this.ribbonButton77.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton77.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton77.Image")));
            this.ribbonButton77.SmallImage = global::RibbonDemo.Properties.Resources.pasteall16;
            this.ribbonButton77.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton77.Tag = null;
            this.ribbonButton77.Text = "Vew clipboardcontent";
            this.ribbonButton77.ToolTip = null;
            this.ribbonButton77.ToolTipImage = null;
            this.ribbonButton77.ToolTipTitle = null;
            // 
            // ribbonButton87
            // 
            this.ribbonButton87.AltKey = null;
            this.ribbonButton87.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton87.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton87.Image")));
            this.ribbonButton87.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton87.SmallImage")));
            this.ribbonButton87.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton87.Tag = null;
            this.ribbonButton87.Text = "ribbonButton87";
            this.ribbonButton87.ToolTip = null;
            this.ribbonButton87.ToolTipImage = null;
            this.ribbonButton87.ToolTipTitle = null;
            // 
            // ribbonButton2
            // 
            this.ribbonButton2.AltKey = null;
            this.ribbonButton2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.Image")));
            this.ribbonButton2.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.SmallImage")));
            this.ribbonButton2.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton2.Tag = null;
            this.ribbonButton2.Text = "Cut";
            this.ribbonButton2.ToolTip = null;
            this.ribbonButton2.ToolTipImage = null;
            this.ribbonButton2.ToolTipTitle = null;
            // 
            // ribbonButton3
            // 
            this.ribbonButton3.AltKey = null;
            this.ribbonButton3.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton3.Image")));
            this.ribbonButton3.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton3.SmallImage")));
            this.ribbonButton3.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton3.Tag = null;
            this.ribbonButton3.Text = "Copy";
            this.ribbonButton3.ToolTip = null;
            this.ribbonButton3.ToolTipImage = null;
            this.ribbonButton3.ToolTipTitle = null;
            // 
            // ribbonButton4
            // 
            this.ribbonButton4.AltKey = null;
            this.ribbonButton4.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton4.Image")));
            this.ribbonButton4.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton4.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton4.SmallImage")));
            this.ribbonButton4.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton4.Tag = null;
            this.ribbonButton4.Text = "Format Painter";
            this.ribbonButton4.ToolTip = null;
            this.ribbonButton4.ToolTipImage = null;
            this.ribbonButton4.ToolTipTitle = null;
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.FlowsTo = System.Windows.Forms.RibbonPanelFlowDirection.Right;
            this.ribbonPanel2.Image = global::RibbonDemo.Properties.Resources.fill16;
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup1);
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup2);
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup3);
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup4);
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup5);
            this.ribbonPanel2.Items.Add(this.ribbonItemGroup13);
            this.ribbonPanel2.Tag = null;
            this.ribbonPanel2.Text = "Font";
            // 
            // ribbonItemGroup1
            // 
            this.ribbonItemGroup1.AltKey = null;
            this.ribbonItemGroup1.Image = null;
            this.ribbonItemGroup1.Items.Add(this.ribbonButton5);
            this.ribbonItemGroup1.Items.Add(this.ribbonButton6);
            this.ribbonItemGroup1.Tag = null;
            this.ribbonItemGroup1.Text = "ribbonItemGroup1";
            this.ribbonItemGroup1.ToolTip = null;
            this.ribbonItemGroup1.ToolTipImage = null;
            this.ribbonItemGroup1.ToolTipTitle = null;
            // 
            // ribbonButton5
            // 
            this.ribbonButton5.AltKey = null;
            this.ribbonButton5.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton5.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton5.Image")));
            this.ribbonButton5.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton5.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton5.SmallImage")));
            this.ribbonButton5.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton5.Tag = null;
            this.ribbonButton5.Text = "ribbonButton5";
            this.ribbonButton5.ToolTip = null;
            this.ribbonButton5.ToolTipImage = null;
            this.ribbonButton5.ToolTipTitle = null;
            // 
            // ribbonButton6
            // 
            this.ribbonButton6.AltKey = null;
            this.ribbonButton6.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton6.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton6.Image")));
            this.ribbonButton6.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton6.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton6.SmallImage")));
            this.ribbonButton6.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton6.Tag = null;
            this.ribbonButton6.Text = "ribbonButton6";
            this.ribbonButton6.ToolTip = null;
            this.ribbonButton6.ToolTipImage = null;
            this.ribbonButton6.ToolTipTitle = null;
            // 
            // ribbonItemGroup2
            // 
            this.ribbonItemGroup2.AltKey = null;
            this.ribbonItemGroup2.Image = null;
            this.ribbonItemGroup2.Items.Add(this.ribbonButton7);
            this.ribbonItemGroup2.Tag = null;
            this.ribbonItemGroup2.Text = "ribbonItemGroup2";
            this.ribbonItemGroup2.ToolTip = null;
            this.ribbonItemGroup2.ToolTipImage = null;
            this.ribbonItemGroup2.ToolTipTitle = null;
            // 
            // ribbonButton7
            // 
            this.ribbonButton7.AltKey = null;
            this.ribbonButton7.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton7.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton7.Image")));
            this.ribbonButton7.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton7.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton7.SmallImage")));
            this.ribbonButton7.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton7.Tag = null;
            this.ribbonButton7.Text = "ribbonButton7";
            this.ribbonButton7.ToolTip = null;
            this.ribbonButton7.ToolTipImage = null;
            this.ribbonButton7.ToolTipTitle = null;
            // 
            // ribbonItemGroup3
            // 
            this.ribbonItemGroup3.AltKey = null;
            this.ribbonItemGroup3.Image = null;
            this.ribbonItemGroup3.Items.Add(this.ribbonButton8);
            this.ribbonItemGroup3.Items.Add(this.ribbonButton9);
            this.ribbonItemGroup3.Items.Add(this.ribbonButton10);
            this.ribbonItemGroup3.Items.Add(this.ribbonButton14);
            this.ribbonItemGroup3.Tag = null;
            this.ribbonItemGroup3.Text = "ribbonItemGroup3";
            this.ribbonItemGroup3.ToolTip = null;
            this.ribbonItemGroup3.ToolTipImage = null;
            this.ribbonItemGroup3.ToolTipTitle = null;
            // 
            // ribbonButton8
            // 
            this.ribbonButton8.AltKey = null;
            this.ribbonButton8.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton8.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton8.Image")));
            this.ribbonButton8.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton8.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton8.SmallImage")));
            this.ribbonButton8.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton8.Tag = null;
            this.ribbonButton8.Text = "ribbonButton8";
            this.ribbonButton8.ToolTip = null;
            this.ribbonButton8.ToolTipImage = null;
            this.ribbonButton8.ToolTipTitle = null;
            // 
            // ribbonButton9
            // 
            this.ribbonButton9.AltKey = null;
            this.ribbonButton9.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton9.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton9.Image")));
            this.ribbonButton9.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton9.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton9.SmallImage")));
            this.ribbonButton9.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton9.Tag = null;
            this.ribbonButton9.Text = "ribbonButton9";
            this.ribbonButton9.ToolTip = null;
            this.ribbonButton9.ToolTipImage = null;
            this.ribbonButton9.ToolTipTitle = null;
            // 
            // ribbonButton10
            // 
            this.ribbonButton10.AltKey = null;
            this.ribbonButton10.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton10.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton10.Image")));
            this.ribbonButton10.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton10.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton10.SmallImage")));
            this.ribbonButton10.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton10.Tag = null;
            this.ribbonButton10.Text = "ribbonButton10";
            this.ribbonButton10.ToolTip = null;
            this.ribbonButton10.ToolTipImage = null;
            this.ribbonButton10.ToolTipTitle = null;
            // 
            // ribbonButton14
            // 
            this.ribbonButton14.AltKey = null;
            this.ribbonButton14.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton14.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton14.Image")));
            this.ribbonButton14.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton14.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton14.SmallImage")));
            this.ribbonButton14.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton14.Tag = null;
            this.ribbonButton14.Text = "ribbonButton14";
            this.ribbonButton14.ToolTip = null;
            this.ribbonButton14.ToolTipImage = null;
            this.ribbonButton14.ToolTipTitle = null;
            // 
            // ribbonItemGroup4
            // 
            this.ribbonItemGroup4.AltKey = null;
            this.ribbonItemGroup4.Image = null;
            this.ribbonItemGroup4.Items.Add(this.ribbonButton11);
            this.ribbonItemGroup4.Items.Add(this.ribbonButton12);
            this.ribbonItemGroup4.Items.Add(this.ribbonButton13);
            this.ribbonItemGroup4.Tag = null;
            this.ribbonItemGroup4.Text = "ribbonItemGroup4";
            this.ribbonItemGroup4.ToolTip = null;
            this.ribbonItemGroup4.ToolTipImage = null;
            this.ribbonItemGroup4.ToolTipTitle = null;
            // 
            // ribbonButton11
            // 
            this.ribbonButton11.AltKey = null;
            this.ribbonButton11.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton11.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton11.Image")));
            this.ribbonButton11.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton11.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton11.SmallImage")));
            this.ribbonButton11.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton11.Tag = null;
            this.ribbonButton11.Text = "ribbonButton11";
            this.ribbonButton11.ToolTip = null;
            this.ribbonButton11.ToolTipImage = null;
            this.ribbonButton11.ToolTipTitle = null;
            // 
            // ribbonButton12
            // 
            this.ribbonButton12.AltKey = null;
            this.ribbonButton12.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton12.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton12.Image")));
            this.ribbonButton12.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton12.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton12.SmallImage")));
            this.ribbonButton12.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton12.Tag = null;
            this.ribbonButton12.Text = "ribbonButton12";
            this.ribbonButton12.ToolTip = null;
            this.ribbonButton12.ToolTipImage = null;
            this.ribbonButton12.ToolTipTitle = null;
            // 
            // ribbonButton13
            // 
            this.ribbonButton13.AltKey = null;
            this.ribbonButton13.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton13.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton13.Image")));
            this.ribbonButton13.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton13.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton13.SmallImage")));
            this.ribbonButton13.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton13.Tag = null;
            this.ribbonButton13.Text = "ribbonButton13";
            this.ribbonButton13.ToolTip = null;
            this.ribbonButton13.ToolTipImage = null;
            this.ribbonButton13.ToolTipTitle = null;
            // 
            // ribbonItemGroup5
            // 
            this.ribbonItemGroup5.AltKey = null;
            this.ribbonItemGroup5.Image = null;
            this.ribbonItemGroup5.Items.Add(this.ribbonColorChooser1);
            this.ribbonItemGroup5.Items.Add(this.ribbonColorChooser2);
            this.ribbonItemGroup5.Tag = null;
            this.ribbonItemGroup5.Text = "ribbonItemGroup5";
            this.ribbonItemGroup5.ToolTip = null;
            this.ribbonItemGroup5.ToolTipImage = null;
            this.ribbonItemGroup5.ToolTipTitle = null;
            // 
            // ribbonColorChooser1
            // 
            this.ribbonColorChooser1.AltKey = null;
            this.ribbonColorChooser1.Color = System.Drawing.Color.Red;
            this.ribbonColorChooser1.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonColorChooser1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser1.Image")));
            this.ribbonColorChooser1.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonColorChooser1.SmallImage = global::RibbonDemo.Properties.Resources.highlight16;
            this.ribbonColorChooser1.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonColorChooser1.Tag = null;
            this.ribbonColorChooser1.Text = "ribbonColorChooser1";
            this.ribbonColorChooser1.ToolTip = null;
            this.ribbonColorChooser1.ToolTipImage = null;
            this.ribbonColorChooser1.ToolTipTitle = null;
            // 
            // ribbonColorChooser2
            // 
            this.ribbonColorChooser2.AltKey = null;
            this.ribbonColorChooser2.Color = System.Drawing.Color.DarkOrange;
            this.ribbonColorChooser2.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonColorChooser2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonColorChooser2.Image")));
            this.ribbonColorChooser2.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonColorChooser2.SmallImage = global::RibbonDemo.Properties.Resources.fontcolor16;
            this.ribbonColorChooser2.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonColorChooser2.Tag = null;
            this.ribbonColorChooser2.Text = "ribbonColorChooser2";
            this.ribbonColorChooser2.ToolTip = null;
            this.ribbonColorChooser2.ToolTipImage = null;
            this.ribbonColorChooser2.ToolTipTitle = null;
            // 
            // ribbonItemGroup13
            // 
            this.ribbonItemGroup13.AltKey = null;
            this.ribbonItemGroup13.DrawBackground = false;
            this.ribbonItemGroup13.Image = null;
            this.ribbonItemGroup13.Items.Add(this.ribbonComboBox2);
            this.ribbonItemGroup13.Items.Add(this.ribbonComboBox3);
            this.ribbonItemGroup13.Tag = null;
            this.ribbonItemGroup13.Text = "ribbonItemGroup13";
            this.ribbonItemGroup13.ToolTip = null;
            this.ribbonItemGroup13.ToolTipImage = null;
            this.ribbonItemGroup13.ToolTipTitle = null;
            // 
            // ribbonComboBox2
            // 
            this.ribbonComboBox2.AltKey = null;
            this.ribbonComboBox2.DropDownItems.Add(this.ribbonSeparator7);
            this.ribbonComboBox2.DropDownItems.Add(this.ribbonButton15);
            this.ribbonComboBox2.DropDownItems.Add(this.ribbonButton16);
            this.ribbonComboBox2.DropDownItems.Add(this.ribbonSeparator8);
            this.ribbonComboBox2.DropDownItems.Add(this.ribbonButton94);
            this.ribbonComboBox2.DropDownItems.Add(this.ribbonButton95);
            this.ribbonComboBox2.DropDownItems.Add(this.ribbonButton96);
            this.ribbonComboBox2.Image = null;
            this.ribbonComboBox2.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonComboBox2.Tag = null;
            this.ribbonComboBox2.Text = "ribbonComboBox2";
            this.ribbonComboBox2.TextBoxText = null;
            this.ribbonComboBox2.ToolTip = null;
            this.ribbonComboBox2.ToolTipImage = null;
            this.ribbonComboBox2.ToolTipTitle = null;
            // 
            // ribbonSeparator7
            // 
            this.ribbonSeparator7.AltKey = null;
            this.ribbonSeparator7.Image = null;
            this.ribbonSeparator7.Tag = null;
            this.ribbonSeparator7.Text = "Recent Fonts";
            this.ribbonSeparator7.ToolTip = null;
            this.ribbonSeparator7.ToolTipImage = null;
            this.ribbonSeparator7.ToolTipTitle = null;
            // 
            // ribbonButton15
            // 
            this.ribbonButton15.AltKey = null;
            this.ribbonButton15.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton15.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton15.Image")));
            this.ribbonButton15.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton15.SmallImage")));
            this.ribbonButton15.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton15.Tag = null;
            this.ribbonButton15.Text = "Arial";
            this.ribbonButton15.ToolTip = null;
            this.ribbonButton15.ToolTipImage = null;
            this.ribbonButton15.ToolTipTitle = null;
            // 
            // ribbonButton16
            // 
            this.ribbonButton16.AltKey = null;
            this.ribbonButton16.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton16.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton16.Image")));
            this.ribbonButton16.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton16.SmallImage")));
            this.ribbonButton16.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton16.Tag = null;
            this.ribbonButton16.Text = "Helvetica";
            this.ribbonButton16.ToolTip = null;
            this.ribbonButton16.ToolTipImage = null;
            this.ribbonButton16.ToolTipTitle = null;
            // 
            // ribbonSeparator8
            // 
            this.ribbonSeparator8.AltKey = null;
            this.ribbonSeparator8.Image = null;
            this.ribbonSeparator8.Tag = null;
            this.ribbonSeparator8.Text = "Other Fonts";
            this.ribbonSeparator8.ToolTip = null;
            this.ribbonSeparator8.ToolTipImage = null;
            this.ribbonSeparator8.ToolTipTitle = null;
            // 
            // ribbonButton94
            // 
            this.ribbonButton94.AltKey = null;
            this.ribbonButton94.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton94.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton94.Image")));
            this.ribbonButton94.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton94.SmallImage")));
            this.ribbonButton94.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton94.Tag = null;
            this.ribbonButton94.Text = "Segoe UI";
            this.ribbonButton94.ToolTip = null;
            this.ribbonButton94.ToolTipImage = null;
            this.ribbonButton94.ToolTipTitle = null;
            // 
            // ribbonButton95
            // 
            this.ribbonButton95.AltKey = null;
            this.ribbonButton95.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton95.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton95.Image")));
            this.ribbonButton95.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton95.SmallImage")));
            this.ribbonButton95.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton95.Tag = null;
            this.ribbonButton95.Text = "Times New Roman";
            this.ribbonButton95.ToolTip = null;
            this.ribbonButton95.ToolTipImage = null;
            this.ribbonButton95.ToolTipTitle = null;
            // 
            // ribbonButton96
            // 
            this.ribbonButton96.AltKey = null;
            this.ribbonButton96.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton96.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton96.Image")));
            this.ribbonButton96.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton96.SmallImage")));
            this.ribbonButton96.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton96.Tag = null;
            this.ribbonButton96.Text = "Courier New";
            this.ribbonButton96.ToolTip = null;
            this.ribbonButton96.ToolTipImage = null;
            this.ribbonButton96.ToolTipTitle = null;
            // 
            // ribbonComboBox3
            // 
            this.ribbonComboBox3.AltKey = null;
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton97);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton98);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton99);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton100);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton101);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton102);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton103);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton104);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton105);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton106);
            this.ribbonComboBox3.DropDownItems.Add(this.ribbonButton107);
            this.ribbonComboBox3.Image = null;
            this.ribbonComboBox3.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonComboBox3.Tag = null;
            this.ribbonComboBox3.Text = "ribbonComboBox3";
            this.ribbonComboBox3.TextBoxText = null;
            this.ribbonComboBox3.TextBoxWidth = 50;
            this.ribbonComboBox3.ToolTip = null;
            this.ribbonComboBox3.ToolTipImage = null;
            this.ribbonComboBox3.ToolTipTitle = null;
            // 
            // ribbonButton97
            // 
            this.ribbonButton97.AltKey = null;
            this.ribbonButton97.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton97.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton97.Image")));
            this.ribbonButton97.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton97.SmallImage")));
            this.ribbonButton97.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton97.Tag = null;
            this.ribbonButton97.Text = "8";
            this.ribbonButton97.ToolTip = null;
            this.ribbonButton97.ToolTipImage = null;
            this.ribbonButton97.ToolTipTitle = null;
            // 
            // ribbonButton98
            // 
            this.ribbonButton98.AltKey = null;
            this.ribbonButton98.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton98.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton98.Image")));
            this.ribbonButton98.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton98.SmallImage")));
            this.ribbonButton98.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton98.Tag = null;
            this.ribbonButton98.Text = "12";
            this.ribbonButton98.ToolTip = null;
            this.ribbonButton98.ToolTipImage = null;
            this.ribbonButton98.ToolTipTitle = null;
            // 
            // ribbonButton99
            // 
            this.ribbonButton99.AltKey = null;
            this.ribbonButton99.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton99.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton99.Image")));
            this.ribbonButton99.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton99.SmallImage")));
            this.ribbonButton99.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton99.Tag = null;
            this.ribbonButton99.Text = "14";
            this.ribbonButton99.ToolTip = null;
            this.ribbonButton99.ToolTipImage = null;
            this.ribbonButton99.ToolTipTitle = null;
            // 
            // ribbonButton100
            // 
            this.ribbonButton100.AltKey = null;
            this.ribbonButton100.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton100.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton100.Image")));
            this.ribbonButton100.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton100.SmallImage")));
            this.ribbonButton100.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton100.Tag = null;
            this.ribbonButton100.Text = "18";
            this.ribbonButton100.ToolTip = null;
            this.ribbonButton100.ToolTipImage = null;
            this.ribbonButton100.ToolTipTitle = null;
            // 
            // ribbonButton101
            // 
            this.ribbonButton101.AltKey = null;
            this.ribbonButton101.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton101.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton101.Image")));
            this.ribbonButton101.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton101.SmallImage")));
            this.ribbonButton101.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton101.Tag = null;
            this.ribbonButton101.Text = "24";
            this.ribbonButton101.ToolTip = null;
            this.ribbonButton101.ToolTipImage = null;
            this.ribbonButton101.ToolTipTitle = null;
            // 
            // ribbonButton102
            // 
            this.ribbonButton102.AltKey = null;
            this.ribbonButton102.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton102.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton102.Image")));
            this.ribbonButton102.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton102.SmallImage")));
            this.ribbonButton102.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton102.Tag = null;
            this.ribbonButton102.Text = "32";
            this.ribbonButton102.ToolTip = null;
            this.ribbonButton102.ToolTipImage = null;
            this.ribbonButton102.ToolTipTitle = null;
            // 
            // ribbonButton103
            // 
            this.ribbonButton103.AltKey = null;
            this.ribbonButton103.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton103.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton103.Image")));
            this.ribbonButton103.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton103.SmallImage")));
            this.ribbonButton103.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton103.Tag = null;
            this.ribbonButton103.Text = "42";
            this.ribbonButton103.ToolTip = null;
            this.ribbonButton103.ToolTipImage = null;
            this.ribbonButton103.ToolTipTitle = null;
            // 
            // ribbonButton104
            // 
            this.ribbonButton104.AltKey = null;
            this.ribbonButton104.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton104.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton104.Image")));
            this.ribbonButton104.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton104.SmallImage")));
            this.ribbonButton104.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton104.Tag = null;
            this.ribbonButton104.Text = "58";
            this.ribbonButton104.ToolTip = null;
            this.ribbonButton104.ToolTipImage = null;
            this.ribbonButton104.ToolTipTitle = null;
            // 
            // ribbonButton105
            // 
            this.ribbonButton105.AltKey = null;
            this.ribbonButton105.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton105.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton105.Image")));
            this.ribbonButton105.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton105.SmallImage")));
            this.ribbonButton105.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton105.Tag = null;
            this.ribbonButton105.Text = "100";
            this.ribbonButton105.ToolTip = null;
            this.ribbonButton105.ToolTipImage = null;
            this.ribbonButton105.ToolTipTitle = null;
            // 
            // ribbonButton106
            // 
            this.ribbonButton106.AltKey = null;
            this.ribbonButton106.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton106.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton106.Image")));
            this.ribbonButton106.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton106.SmallImage")));
            this.ribbonButton106.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton106.Tag = null;
            this.ribbonButton106.Text = "120";
            this.ribbonButton106.ToolTip = null;
            this.ribbonButton106.ToolTipImage = null;
            this.ribbonButton106.ToolTipTitle = null;
            // 
            // ribbonButton107
            // 
            this.ribbonButton107.AltKey = null;
            this.ribbonButton107.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton107.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton107.Image")));
            this.ribbonButton107.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton107.SmallImage")));
            this.ribbonButton107.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton107.Tag = null;
            this.ribbonButton107.Text = "170";
            this.ribbonButton107.ToolTip = null;
            this.ribbonButton107.ToolTipImage = null;
            this.ribbonButton107.ToolTipTitle = null;
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.FlowsTo = System.Windows.Forms.RibbonPanelFlowDirection.Right;
            this.ribbonPanel3.Image = global::RibbonDemo.Properties.Resources.aligncenter16;
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup6);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup7);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup8);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup9);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup10);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup11);
            this.ribbonPanel3.Items.Add(this.ribbonItemGroup12);
            this.ribbonPanel3.Tag = null;
            this.ribbonPanel3.Text = "Paragraph";
            this.ribbonPanel3.ButtonMoreClick += new System.EventHandler(this.ribbonPanel3_ButtonMoreClick);
            // 
            // ribbonItemGroup6
            // 
            this.ribbonItemGroup6.AltKey = null;
            this.ribbonItemGroup6.Image = null;
            this.ribbonItemGroup6.Items.Add(this.ribbonButton17);
            this.ribbonItemGroup6.Items.Add(this.ribbonButton18);
            this.ribbonItemGroup6.Items.Add(this.ribbonButton19);
            this.ribbonItemGroup6.Tag = null;
            this.ribbonItemGroup6.Text = "ribbonItemGroup6";
            this.ribbonItemGroup6.ToolTip = null;
            this.ribbonItemGroup6.ToolTipImage = null;
            this.ribbonItemGroup6.ToolTipTitle = null;
            // 
            // ribbonButton17
            // 
            this.ribbonButton17.AltKey = null;
            this.ribbonButton17.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton17.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton17.Image")));
            this.ribbonButton17.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton17.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton17.SmallImage")));
            this.ribbonButton17.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton17.Tag = null;
            this.ribbonButton17.Text = "ribbonButton17";
            this.ribbonButton17.ToolTip = null;
            this.ribbonButton17.ToolTipImage = null;
            this.ribbonButton17.ToolTipTitle = null;
            // 
            // ribbonButton18
            // 
            this.ribbonButton18.AltKey = null;
            this.ribbonButton18.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton18.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton18.Image")));
            this.ribbonButton18.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton18.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton18.SmallImage")));
            this.ribbonButton18.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton18.Tag = null;
            this.ribbonButton18.Text = "ribbonButton18";
            this.ribbonButton18.ToolTip = null;
            this.ribbonButton18.ToolTipImage = null;
            this.ribbonButton18.ToolTipTitle = null;
            // 
            // ribbonButton19
            // 
            this.ribbonButton19.AltKey = null;
            this.ribbonButton19.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton19.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton19.Image")));
            this.ribbonButton19.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton19.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton19.SmallImage")));
            this.ribbonButton19.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton19.Tag = null;
            this.ribbonButton19.Text = "ribbonButton19";
            this.ribbonButton19.ToolTip = null;
            this.ribbonButton19.ToolTipImage = null;
            this.ribbonButton19.ToolTipTitle = null;
            // 
            // ribbonItemGroup7
            // 
            this.ribbonItemGroup7.AltKey = null;
            this.ribbonItemGroup7.Image = null;
            this.ribbonItemGroup7.Items.Add(this.ribbonButton20);
            this.ribbonItemGroup7.Items.Add(this.ribbonButton21);
            this.ribbonItemGroup7.Items.Add(this.ribbonButton22);
            this.ribbonItemGroup7.Items.Add(this.ribbonButton23);
            this.ribbonItemGroup7.Tag = null;
            this.ribbonItemGroup7.Text = "ribbonItemGroup7";
            this.ribbonItemGroup7.ToolTip = null;
            this.ribbonItemGroup7.ToolTipImage = null;
            this.ribbonItemGroup7.ToolTipTitle = null;
            // 
            // ribbonButton20
            // 
            this.ribbonButton20.AltKey = null;
            this.ribbonButton20.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton20.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton20.Image")));
            this.ribbonButton20.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton20.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton20.SmallImage")));
            this.ribbonButton20.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton20.Tag = null;
            this.ribbonButton20.Text = "ribbonButton20";
            this.ribbonButton20.ToolTip = null;
            this.ribbonButton20.ToolTipImage = null;
            this.ribbonButton20.ToolTipTitle = null;
            // 
            // ribbonButton21
            // 
            this.ribbonButton21.AltKey = null;
            this.ribbonButton21.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton21.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton21.Image")));
            this.ribbonButton21.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton21.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton21.SmallImage")));
            this.ribbonButton21.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton21.Tag = null;
            this.ribbonButton21.Text = "ribbonButton21";
            this.ribbonButton21.ToolTip = null;
            this.ribbonButton21.ToolTipImage = null;
            this.ribbonButton21.ToolTipTitle = null;
            // 
            // ribbonButton22
            // 
            this.ribbonButton22.AltKey = null;
            this.ribbonButton22.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton22.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton22.Image")));
            this.ribbonButton22.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton22.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton22.SmallImage")));
            this.ribbonButton22.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton22.Tag = null;
            this.ribbonButton22.Text = "ribbonButton22";
            this.ribbonButton22.ToolTip = null;
            this.ribbonButton22.ToolTipImage = null;
            this.ribbonButton22.ToolTipTitle = null;
            // 
            // ribbonButton23
            // 
            this.ribbonButton23.AltKey = null;
            this.ribbonButton23.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton23.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton23.Image")));
            this.ribbonButton23.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton23.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton23.SmallImage")));
            this.ribbonButton23.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton23.Tag = null;
            this.ribbonButton23.Text = "ribbonButton23";
            this.ribbonButton23.ToolTip = null;
            this.ribbonButton23.ToolTipImage = null;
            this.ribbonButton23.ToolTipTitle = null;
            // 
            // ribbonItemGroup8
            // 
            this.ribbonItemGroup8.AltKey = null;
            this.ribbonItemGroup8.Image = null;
            this.ribbonItemGroup8.Items.Add(this.ribbonButton24);
            this.ribbonItemGroup8.Tag = null;
            this.ribbonItemGroup8.Text = "ribbonItemGroup8";
            this.ribbonItemGroup8.ToolTip = null;
            this.ribbonItemGroup8.ToolTipImage = null;
            this.ribbonItemGroup8.ToolTipTitle = null;
            // 
            // ribbonButton24
            // 
            this.ribbonButton24.AltKey = null;
            this.ribbonButton24.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton24.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton24.Image")));
            this.ribbonButton24.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton24.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton24.SmallImage")));
            this.ribbonButton24.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton24.Tag = null;
            this.ribbonButton24.Text = "ribbonButton24";
            this.ribbonButton24.ToolTip = null;
            this.ribbonButton24.ToolTipImage = null;
            this.ribbonButton24.ToolTipTitle = null;
            // 
            // ribbonItemGroup9
            // 
            this.ribbonItemGroup9.AltKey = null;
            this.ribbonItemGroup9.Image = null;
            this.ribbonItemGroup9.Items.Add(this.ribbonButton25);
            this.ribbonItemGroup9.Items.Add(this.ribbonButton26);
            this.ribbonItemGroup9.Tag = null;
            this.ribbonItemGroup9.Text = "ribbonItemGroup9";
            this.ribbonItemGroup9.ToolTip = null;
            this.ribbonItemGroup9.ToolTipImage = null;
            this.ribbonItemGroup9.ToolTipTitle = null;
            // 
            // ribbonButton25
            // 
            this.ribbonButton25.AltKey = null;
            this.ribbonButton25.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton25.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton25.Image")));
            this.ribbonButton25.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton25.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton25.SmallImage")));
            this.ribbonButton25.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton25.Tag = null;
            this.ribbonButton25.Text = "ribbonButton25";
            this.ribbonButton25.ToolTip = null;
            this.ribbonButton25.ToolTipImage = null;
            this.ribbonButton25.ToolTipTitle = null;
            // 
            // ribbonButton26
            // 
            this.ribbonButton26.AltKey = null;
            this.ribbonButton26.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton26.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton26.Image")));
            this.ribbonButton26.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton26.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton26.SmallImage")));
            this.ribbonButton26.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton26.Tag = null;
            this.ribbonButton26.Text = "ribbonButton26";
            this.ribbonButton26.ToolTip = null;
            this.ribbonButton26.ToolTipImage = null;
            this.ribbonButton26.ToolTipTitle = null;
            // 
            // ribbonItemGroup10
            // 
            this.ribbonItemGroup10.AltKey = null;
            this.ribbonItemGroup10.Image = null;
            this.ribbonItemGroup10.Items.Add(this.ribbonButton27);
            this.ribbonItemGroup10.Tag = null;
            this.ribbonItemGroup10.Text = "ribbonItemGroup10";
            this.ribbonItemGroup10.ToolTip = null;
            this.ribbonItemGroup10.ToolTipImage = null;
            this.ribbonItemGroup10.ToolTipTitle = null;
            // 
            // ribbonButton27
            // 
            this.ribbonButton27.AltKey = null;
            this.ribbonButton27.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton27.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton27.Image")));
            this.ribbonButton27.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton27.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton27.SmallImage")));
            this.ribbonButton27.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton27.Tag = null;
            this.ribbonButton27.Text = "ribbonButton27";
            this.ribbonButton27.ToolTip = null;
            this.ribbonButton27.ToolTipImage = null;
            this.ribbonButton27.ToolTipTitle = null;
            // 
            // ribbonItemGroup11
            // 
            this.ribbonItemGroup11.AltKey = null;
            this.ribbonItemGroup11.Image = null;
            this.ribbonItemGroup11.Items.Add(this.ribbonButton28);
            this.ribbonItemGroup11.Tag = null;
            this.ribbonItemGroup11.Text = "ribbonItemGroup11";
            this.ribbonItemGroup11.ToolTip = null;
            this.ribbonItemGroup11.ToolTipImage = null;
            this.ribbonItemGroup11.ToolTipTitle = null;
            // 
            // ribbonButton28
            // 
            this.ribbonButton28.AltKey = null;
            this.ribbonButton28.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton28.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton28.Image")));
            this.ribbonButton28.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton28.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton28.SmallImage")));
            this.ribbonButton28.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton28.Tag = null;
            this.ribbonButton28.Text = "ribbonButton28";
            this.ribbonButton28.ToolTip = null;
            this.ribbonButton28.ToolTipImage = null;
            this.ribbonButton28.ToolTipTitle = null;
            // 
            // ribbonItemGroup12
            // 
            this.ribbonItemGroup12.AltKey = null;
            this.ribbonItemGroup12.Image = null;
            this.ribbonItemGroup12.Items.Add(this.ribbonButton29);
            this.ribbonItemGroup12.Items.Add(this.ribbonButton30);
            this.ribbonItemGroup12.Tag = null;
            this.ribbonItemGroup12.Text = "ribbonItemGroup12";
            this.ribbonItemGroup12.ToolTip = null;
            this.ribbonItemGroup12.ToolTipImage = null;
            this.ribbonItemGroup12.ToolTipTitle = null;
            // 
            // ribbonButton29
            // 
            this.ribbonButton29.AltKey = null;
            this.ribbonButton29.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton29.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton29.Image")));
            this.ribbonButton29.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton29.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton29.SmallImage")));
            this.ribbonButton29.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton29.Tag = null;
            this.ribbonButton29.Text = "ribbonButton29";
            this.ribbonButton29.ToolTip = null;
            this.ribbonButton29.ToolTipImage = null;
            this.ribbonButton29.ToolTipTitle = null;
            // 
            // ribbonButton30
            // 
            this.ribbonButton30.AltKey = null;
            this.ribbonButton30.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton30.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton30.Image")));
            this.ribbonButton30.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton30.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton30.SmallImage")));
            this.ribbonButton30.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton30.Tag = null;
            this.ribbonButton30.Text = "ribbonButton30";
            this.ribbonButton30.ToolTip = null;
            this.ribbonButton30.ToolTipImage = null;
            this.ribbonButton30.ToolTipTitle = null;
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.ButtonMoreEnabled = false;
            this.ribbonPanel4.ButtonMoreVisible = false;
            this.ribbonPanel4.Image = global::RibbonDemo.Properties.Resources.style16;
            this.ribbonPanel4.Items.Add(this.lst);
            this.ribbonPanel4.Items.Add(this.ribbonButton34);
            this.ribbonPanel4.Tag = null;
            this.ribbonPanel4.Text = "Styles";
            // 
            // lst
            // 
            this.lst.AltKey = null;
            this.lst.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.lst.Image = null;
            this.lst.ItemsSizeInDropwDownMode = new System.Drawing.Size(7, 5);
            this.lst.ItemsWideInLargeMode = 9;
            this.lst.Tag = null;
            this.lst.Text = "ribbonButtonList2";
            this.lst.ToolTip = null;
            this.lst.ToolTipImage = null;
            this.lst.ToolTipTitle = null;
            // 
            // ribbonButton34
            // 
            this.ribbonButton34.AltKey = null;
            this.ribbonButton34.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton34.DropDownItems.Add(this.ribbonSeparator5);
            this.ribbonButton34.DropDownItems.Add(this.ribbonButton80);
            this.ribbonButton34.DropDownItems.Add(this.ribbonButton81);
            this.ribbonButton34.DropDownItems.Add(this.ribbonButton82);
            this.ribbonButton34.DropDownItems.Add(this.ribbonSeparator4);
            this.ribbonButton34.DropDownItems.Add(this.ribbonButton83);
            this.ribbonButton34.Image = global::RibbonDemo.Properties.Resources.style32;
            this.ribbonButton34.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton34.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton34.SmallImage")));
            this.ribbonButton34.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton34.Tag = null;
            this.ribbonButton34.Text = "Change Styles";
            this.ribbonButton34.ToolTip = null;
            this.ribbonButton34.ToolTipImage = null;
            this.ribbonButton34.ToolTipTitle = null;
            // 
            // ribbonSeparator5
            // 
            this.ribbonSeparator5.AltKey = null;
            this.ribbonSeparator5.Image = null;
            this.ribbonSeparator5.Tag = null;
            this.ribbonSeparator5.Text = "Recently used styles ";
            this.ribbonSeparator5.ToolTip = null;
            this.ribbonSeparator5.ToolTipImage = null;
            this.ribbonSeparator5.ToolTipTitle = null;
            // 
            // ribbonButton80
            // 
            this.ribbonButton80.AltKey = null;
            this.ribbonButton80.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton80.DropDownItems.Add(this.ribbonButton84);
            this.ribbonButton80.DropDownItems.Add(this.ribbonButton85);
            this.ribbonButton80.DropDownItems.Add(this.ribbonButton86);
            this.ribbonButton80.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton80.Image")));
            this.ribbonButton80.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton80.SmallImage")));
            this.ribbonButton80.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton80.Tag = null;
            this.ribbonButton80.Text = "Style 1";
            this.ribbonButton80.ToolTip = null;
            this.ribbonButton80.ToolTipImage = null;
            this.ribbonButton80.ToolTipTitle = null;
            // 
            // ribbonButton84
            // 
            this.ribbonButton84.AltKey = null;
            this.ribbonButton84.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton84.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton84.Image")));
            this.ribbonButton84.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton84.SmallImage")));
            this.ribbonButton84.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton84.Tag = null;
            this.ribbonButton84.Text = "Sub-Style1";
            this.ribbonButton84.ToolTip = null;
            this.ribbonButton84.ToolTipImage = null;
            this.ribbonButton84.ToolTipTitle = null;
            // 
            // ribbonButton85
            // 
            this.ribbonButton85.AltKey = null;
            this.ribbonButton85.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton85.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton85.Image")));
            this.ribbonButton85.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton85.SmallImage")));
            this.ribbonButton85.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton85.Tag = null;
            this.ribbonButton85.Text = "Sub-Style2";
            this.ribbonButton85.ToolTip = null;
            this.ribbonButton85.ToolTipImage = null;
            this.ribbonButton85.ToolTipTitle = null;
            // 
            // ribbonButton86
            // 
            this.ribbonButton86.AltKey = null;
            this.ribbonButton86.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton86.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton86.Image")));
            this.ribbonButton86.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton86.SmallImage")));
            this.ribbonButton86.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton86.Tag = null;
            this.ribbonButton86.Text = "Sub-Style3";
            this.ribbonButton86.ToolTip = null;
            this.ribbonButton86.ToolTipImage = null;
            this.ribbonButton86.ToolTipTitle = null;
            // 
            // ribbonButton81
            // 
            this.ribbonButton81.AltKey = null;
            this.ribbonButton81.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton81.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton81.Image")));
            this.ribbonButton81.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton81.SmallImage")));
            this.ribbonButton81.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton81.Tag = null;
            this.ribbonButton81.Text = "Style 2";
            this.ribbonButton81.ToolTip = null;
            this.ribbonButton81.ToolTipImage = null;
            this.ribbonButton81.ToolTipTitle = null;
            // 
            // ribbonButton82
            // 
            this.ribbonButton82.AltKey = null;
            this.ribbonButton82.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton82.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton82.Image")));
            this.ribbonButton82.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton82.SmallImage")));
            this.ribbonButton82.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton82.Tag = null;
            this.ribbonButton82.Text = "Style 3";
            this.ribbonButton82.ToolTip = null;
            this.ribbonButton82.ToolTipImage = null;
            this.ribbonButton82.ToolTipTitle = null;
            // 
            // ribbonSeparator4
            // 
            this.ribbonSeparator4.AltKey = null;
            this.ribbonSeparator4.Image = null;
            this.ribbonSeparator4.Tag = null;
            this.ribbonSeparator4.Text = null;
            this.ribbonSeparator4.ToolTip = null;
            this.ribbonSeparator4.ToolTipImage = null;
            this.ribbonSeparator4.ToolTipTitle = null;
            // 
            // ribbonButton83
            // 
            this.ribbonButton83.AltKey = null;
            this.ribbonButton83.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton83.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton83.Image")));
            this.ribbonButton83.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton83.SmallImage")));
            this.ribbonButton83.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton83.Tag = null;
            this.ribbonButton83.Text = "More";
            this.ribbonButton83.ToolTip = null;
            this.ribbonButton83.ToolTipImage = null;
            this.ribbonButton83.ToolTipTitle = null;
            // 
            // ribbonPanel5
            // 
            this.ribbonPanel5.ButtonMoreEnabled = false;
            this.ribbonPanel5.ButtonMoreVisible = false;
            this.ribbonPanel5.Image = global::RibbonDemo.Properties.Resources.lookup16;
            this.ribbonPanel5.Items.Add(this.ribbonButton31);
            this.ribbonPanel5.Items.Add(this.ribbonButton32);
            this.ribbonPanel5.Items.Add(this.ribbonButton33);
            this.ribbonPanel5.Tag = null;
            this.ribbonPanel5.Text = "Editing";
            // 
            // ribbonButton31
            // 
            this.ribbonButton31.AltKey = null;
            this.ribbonButton31.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton31.DropDownItems.Add(this.ribbonButton78);
            this.ribbonButton31.DropDownItems.Add(this.ribbonButton79);
            this.ribbonButton31.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton31.Image")));
            this.ribbonButton31.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton31.SmallImage")));
            this.ribbonButton31.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton31.Tag = null;
            this.ribbonButton31.Text = "Find";
            this.ribbonButton31.ToolTip = null;
            this.ribbonButton31.ToolTipImage = null;
            this.ribbonButton31.ToolTipTitle = null;
            // 
            // ribbonButton78
            // 
            this.ribbonButton78.AltKey = null;
            this.ribbonButton78.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton78.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton78.Image")));
            this.ribbonButton78.SmallImage = global::RibbonDemo.Properties.Resources.lookup16;
            this.ribbonButton78.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton78.Tag = null;
            this.ribbonButton78.Text = "Find in document...";
            this.ribbonButton78.ToolTip = null;
            this.ribbonButton78.ToolTipImage = null;
            this.ribbonButton78.ToolTipTitle = null;
            // 
            // ribbonButton79
            // 
            this.ribbonButton79.AltKey = null;
            this.ribbonButton79.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton79.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton79.Image")));
            this.ribbonButton79.SmallImage = global::RibbonDemo.Properties.Resources.goforward16;
            this.ribbonButton79.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton79.Tag = null;
            this.ribbonButton79.Text = "Go to";
            this.ribbonButton79.ToolTip = "Go to ...";
            this.ribbonButton79.ToolTipImage = null;
            this.ribbonButton79.ToolTipTitle = null;
            // 
            // ribbonButton32
            // 
            this.ribbonButton32.AltKey = null;
            this.ribbonButton32.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton32.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton32.Image")));
            this.ribbonButton32.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton32.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton32.SmallImage")));
            this.ribbonButton32.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton32.Tag = null;
            this.ribbonButton32.Text = "Replace";
            this.ribbonButton32.ToolTip = null;
            this.ribbonButton32.ToolTipImage = null;
            this.ribbonButton32.ToolTipTitle = null;
            // 
            // ribbonButton33
            // 
            this.ribbonButton33.AltKey = null;
            this.ribbonButton33.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton33.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton33.Image")));
            this.ribbonButton33.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton33.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton33.SmallImage")));
            this.ribbonButton33.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton33.Tag = null;
            this.ribbonButton33.Text = "Select";
            this.ribbonButton33.ToolTip = null;
            this.ribbonButton33.ToolTipImage = null;
            this.ribbonButton33.ToolTipTitle = null;
            // 
            // ribbonTab2
            // 
            this.ribbonTab2.Panels.Add(this.ribbonPanel6);
            this.ribbonTab2.Panels.Add(this.ribbonPanel7);
            this.ribbonTab2.Panels.Add(this.ribbonPanel8);
            this.ribbonTab2.Panels.Add(this.ribbonPanel9);
            this.ribbonTab2.Panels.Add(this.ribbonPanel10);
            this.ribbonTab2.Panels.Add(this.ribbonPanel11);
            this.ribbonTab2.Panels.Add(this.ribbonPanel12);
            this.ribbonTab2.Tag = null;
            this.ribbonTab2.Text = "Insert";
            // 
            // ribbonPanel6
            // 
            this.ribbonPanel6.ButtonMoreEnabled = false;
            this.ribbonPanel6.ButtonMoreVisible = false;
            this.ribbonPanel6.Image = global::RibbonDemo.Properties.Resources.cover16;
            this.ribbonPanel6.Items.Add(this.ribbonButton37);
            this.ribbonPanel6.Items.Add(this.ribbonButton38);
            this.ribbonPanel6.Items.Add(this.ribbonButton39);
            this.ribbonPanel6.Tag = null;
            this.ribbonPanel6.Text = "Pages";
            // 
            // ribbonButton37
            // 
            this.ribbonButton37.AltKey = null;
            this.ribbonButton37.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton37.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton37.Image")));
            this.ribbonButton37.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton37.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton37.SmallImage")));
            this.ribbonButton37.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton37.Tag = null;
            this.ribbonButton37.Text = "Cover";
            this.ribbonButton37.ToolTip = null;
            this.ribbonButton37.ToolTipImage = null;
            this.ribbonButton37.ToolTipTitle = null;
            // 
            // ribbonButton38
            // 
            this.ribbonButton38.AltKey = null;
            this.ribbonButton38.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton38.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton38.Image")));
            this.ribbonButton38.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton38.SmallImage")));
            this.ribbonButton38.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton38.Tag = null;
            this.ribbonButton38.Text = "Blank page";
            this.ribbonButton38.ToolTip = null;
            this.ribbonButton38.ToolTipImage = null;
            this.ribbonButton38.ToolTipTitle = null;
            // 
            // ribbonButton39
            // 
            this.ribbonButton39.AltKey = null;
            this.ribbonButton39.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton39.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton39.Image")));
            this.ribbonButton39.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton39.SmallImage")));
            this.ribbonButton39.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton39.Tag = null;
            this.ribbonButton39.Text = "Page jump";
            this.ribbonButton39.ToolTip = null;
            this.ribbonButton39.ToolTipImage = null;
            this.ribbonButton39.ToolTipTitle = null;
            // 
            // ribbonPanel7
            // 
            this.ribbonPanel7.ButtonMoreEnabled = false;
            this.ribbonPanel7.ButtonMoreVisible = false;
            this.ribbonPanel7.Image = global::RibbonDemo.Properties.Resources.table16;
            this.ribbonPanel7.Items.Add(this.ribbonButton40);
            this.ribbonPanel7.Tag = null;
            this.ribbonPanel7.Text = "Tables";
            // 
            // ribbonButton40
            // 
            this.ribbonButton40.AltKey = null;
            this.ribbonButton40.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton40.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton40.Image")));
            this.ribbonButton40.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton40.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton40.SmallImage")));
            this.ribbonButton40.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton40.Tag = null;
            this.ribbonButton40.Text = "Table";
            this.ribbonButton40.ToolTip = null;
            this.ribbonButton40.ToolTipImage = null;
            this.ribbonButton40.ToolTipTitle = null;
            // 
            // ribbonPanel8
            // 
            this.ribbonPanel8.ButtonMoreEnabled = false;
            this.ribbonPanel8.ButtonMoreVisible = false;
            this.ribbonPanel8.Image = global::RibbonDemo.Properties.Resources.palette16;
            this.ribbonPanel8.Items.Add(this.ribbonButton41);
            this.ribbonPanel8.Items.Add(this.ribbonButton42);
            this.ribbonPanel8.Items.Add(this.ribbonButton43);
            this.ribbonPanel8.Items.Add(this.ribbonButton44);
            this.ribbonPanel8.Items.Add(this.ribbonButton45);
            this.ribbonPanel8.Tag = null;
            this.ribbonPanel8.Text = "Graphics";
            // 
            // ribbonButton41
            // 
            this.ribbonButton41.AltKey = null;
            this.ribbonButton41.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton41.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton41.Image")));
            this.ribbonButton41.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton41.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton41.SmallImage")));
            this.ribbonButton41.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton41.Tag = null;
            this.ribbonButton41.Text = "Image";
            this.ribbonButton41.ToolTip = null;
            this.ribbonButton41.ToolTipImage = null;
            this.ribbonButton41.ToolTipTitle = null;
            // 
            // ribbonButton42
            // 
            this.ribbonButton42.AltKey = null;
            this.ribbonButton42.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton42.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton42.Image")));
            this.ribbonButton42.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton42.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton42.SmallImage")));
            this.ribbonButton42.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton42.Tag = null;
            this.ribbonButton42.Text = "Clip";
            this.ribbonButton42.ToolTip = null;
            this.ribbonButton42.ToolTipImage = null;
            this.ribbonButton42.ToolTipTitle = null;
            // 
            // ribbonButton43
            // 
            this.ribbonButton43.AltKey = null;
            this.ribbonButton43.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton43.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton43.Image")));
            this.ribbonButton43.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton43.SmallImage")));
            this.ribbonButton43.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton43.Tag = null;
            this.ribbonButton43.Text = "Shapes";
            this.ribbonButton43.ToolTip = null;
            this.ribbonButton43.ToolTipImage = null;
            this.ribbonButton43.ToolTipTitle = null;
            // 
            // ribbonButton44
            // 
            this.ribbonButton44.AltKey = null;
            this.ribbonButton44.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton44.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton44.Image")));
            this.ribbonButton44.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton44.SmallImage")));
            this.ribbonButton44.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton44.Tag = null;
            this.ribbonButton44.Text = "SmartArt";
            this.ribbonButton44.ToolTip = null;
            this.ribbonButton44.ToolTipImage = null;
            this.ribbonButton44.ToolTipTitle = null;
            this.ribbonButton44.Click += new System.EventHandler(this.ribbonButton44_Click);
            // 
            // ribbonButton45
            // 
            this.ribbonButton45.AltKey = null;
            this.ribbonButton45.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton45.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton45.Image")));
            this.ribbonButton45.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton45.SmallImage")));
            this.ribbonButton45.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton45.Tag = null;
            this.ribbonButton45.Text = "Chart";
            this.ribbonButton45.ToolTip = null;
            this.ribbonButton45.ToolTipImage = null;
            this.ribbonButton45.ToolTipTitle = null;
            // 
            // ribbonPanel9
            // 
            this.ribbonPanel9.ButtonMoreEnabled = false;
            this.ribbonPanel9.ButtonMoreVisible = false;
            this.ribbonPanel9.Image = global::RibbonDemo.Properties.Resources.link16;
            this.ribbonPanel9.Items.Add(this.ribbonButton46);
            this.ribbonPanel9.Items.Add(this.ribbonButton47);
            this.ribbonPanel9.Tag = null;
            this.ribbonPanel9.Text = "Links";
            // 
            // ribbonButton46
            // 
            this.ribbonButton46.AltKey = null;
            this.ribbonButton46.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton46.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton46.Image")));
            this.ribbonButton46.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton46.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton46.SmallImage")));
            this.ribbonButton46.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton46.Tag = null;
            this.ribbonButton46.Text = "Link";
            this.ribbonButton46.ToolTip = null;
            this.ribbonButton46.ToolTipImage = null;
            this.ribbonButton46.ToolTipTitle = null;
            // 
            // ribbonButton47
            // 
            this.ribbonButton47.AltKey = null;
            this.ribbonButton47.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton47.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton47.Image")));
            this.ribbonButton47.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton47.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton47.SmallImage")));
            this.ribbonButton47.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton47.Tag = null;
            this.ribbonButton47.Text = "Remove link";
            this.ribbonButton47.ToolTip = null;
            this.ribbonButton47.ToolTipImage = null;
            this.ribbonButton47.ToolTipTitle = null;
            // 
            // ribbonPanel10
            // 
            this.ribbonPanel10.ButtonMoreEnabled = false;
            this.ribbonPanel10.ButtonMoreVisible = false;
            this.ribbonPanel10.Image = global::RibbonDemo.Properties.Resources.header16;
            this.ribbonPanel10.Items.Add(this.ribbonButton48);
            this.ribbonPanel10.Items.Add(this.ribbonButton49);
            this.ribbonPanel10.Items.Add(this.ribbonButton50);
            this.ribbonPanel10.Tag = null;
            this.ribbonPanel10.Text = "Header and Footer";
            // 
            // ribbonButton48
            // 
            this.ribbonButton48.AltKey = null;
            this.ribbonButton48.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton48.DropDownItems.Add(this.ribbonButton70);
            this.ribbonButton48.DropDownItems.Add(this.ribbonButton71);
            this.ribbonButton48.DropDownItems.Add(this.ribbonButton72);
            this.ribbonButton48.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton48.Image")));
            this.ribbonButton48.SmallImage = global::RibbonDemo.Properties.Resources.header16;
            this.ribbonButton48.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton48.Tag = null;
            this.ribbonButton48.Text = "Header";
            this.ribbonButton48.ToolTip = null;
            this.ribbonButton48.ToolTipImage = null;
            this.ribbonButton48.ToolTipTitle = null;
            // 
            // ribbonButton70
            // 
            this.ribbonButton70.AltKey = null;
            this.ribbonButton70.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton70.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton70.Image")));
            this.ribbonButton70.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton70.SmallImage")));
            this.ribbonButton70.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton70.Tag = null;
            this.ribbonButton70.Text = "Regular";
            this.ribbonButton70.ToolTip = null;
            this.ribbonButton70.ToolTipImage = null;
            this.ribbonButton70.ToolTipTitle = null;
            // 
            // ribbonButton71
            // 
            this.ribbonButton71.AltKey = null;
            this.ribbonButton71.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton71.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton71.Image")));
            this.ribbonButton71.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton71.SmallImage")));
            this.ribbonButton71.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton71.Tag = null;
            this.ribbonButton71.Text = "Special";
            this.ribbonButton71.ToolTip = null;
            this.ribbonButton71.ToolTipImage = null;
            this.ribbonButton71.ToolTipTitle = null;
            // 
            // ribbonButton72
            // 
            this.ribbonButton72.AltKey = null;
            this.ribbonButton72.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton72.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton72.Image")));
            this.ribbonButton72.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton72.SmallImage")));
            this.ribbonButton72.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton72.Tag = null;
            this.ribbonButton72.Text = "Happy";
            this.ribbonButton72.ToolTip = null;
            this.ribbonButton72.ToolTipImage = null;
            this.ribbonButton72.ToolTipTitle = null;
            // 
            // ribbonButton49
            // 
            this.ribbonButton49.AltKey = null;
            this.ribbonButton49.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton49.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton49.Image")));
            this.ribbonButton49.SmallImage = global::RibbonDemo.Properties.Resources.footer16;
            this.ribbonButton49.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton49.Tag = null;
            this.ribbonButton49.Text = "Footer";
            this.ribbonButton49.ToolTip = null;
            this.ribbonButton49.ToolTipImage = null;
            this.ribbonButton49.ToolTipTitle = null;
            // 
            // ribbonButton50
            // 
            this.ribbonButton50.AltKey = null;
            this.ribbonButton50.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton50.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton50.Image")));
            this.ribbonButton50.SmallImage = global::RibbonDemo.Properties.Resources.pagenumber16;
            this.ribbonButton50.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton50.Tag = null;
            this.ribbonButton50.Text = "Page number";
            this.ribbonButton50.ToolTip = null;
            this.ribbonButton50.ToolTipImage = null;
            this.ribbonButton50.ToolTipTitle = null;
            // 
            // ribbonPanel11
            // 
            this.ribbonPanel11.ButtonMoreEnabled = false;
            this.ribbonPanel11.ButtonMoreVisible = false;
            this.ribbonPanel11.Image = global::RibbonDemo.Properties.Resources.wordart16;
            this.ribbonPanel11.Items.Add(this.ribbonButton51);
            this.ribbonPanel11.Items.Add(this.ribbonButton52);
            this.ribbonPanel11.Items.Add(this.ribbonButton53);
            this.ribbonPanel11.Items.Add(this.ribbonButton54);
            this.ribbonPanel11.Items.Add(this.ribbonButton55);
            this.ribbonPanel11.Items.Add(this.ribbonButton56);
            this.ribbonPanel11.Items.Add(this.ribbonButton57);
            this.ribbonPanel11.Tag = null;
            this.ribbonPanel11.Text = "Text";
            // 
            // ribbonButton51
            // 
            this.ribbonButton51.AltKey = null;
            this.ribbonButton51.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton51.Image = global::RibbonDemo.Properties.Resources.textframe32;
            this.ribbonButton51.SmallImage = global::RibbonDemo.Properties.Resources.textframe16;
            this.ribbonButton51.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton51.Tag = null;
            this.ribbonButton51.Text = "Text frame";
            this.ribbonButton51.ToolTip = null;
            this.ribbonButton51.ToolTipImage = null;
            this.ribbonButton51.ToolTipTitle = null;
            // 
            // ribbonButton52
            // 
            this.ribbonButton52.AltKey = null;
            this.ribbonButton52.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton52.Image = global::RibbonDemo.Properties.Resources.quickitems32;
            this.ribbonButton52.SmallImage = global::RibbonDemo.Properties.Resources.quickitems16;
            this.ribbonButton52.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton52.Tag = null;
            this.ribbonButton52.Text = "Quick elements";
            this.ribbonButton52.ToolTip = null;
            this.ribbonButton52.ToolTipImage = null;
            this.ribbonButton52.ToolTipTitle = null;
            // 
            // ribbonButton53
            // 
            this.ribbonButton53.AltKey = null;
            this.ribbonButton53.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton53.Image = global::RibbonDemo.Properties.Resources.wordart32;
            this.ribbonButton53.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton53.SmallImage")));
            this.ribbonButton53.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton53.Tag = null;
            this.ribbonButton53.Text = "WordArt";
            this.ribbonButton53.ToolTip = null;
            this.ribbonButton53.ToolTipImage = null;
            this.ribbonButton53.ToolTipTitle = null;
            // 
            // ribbonButton54
            // 
            this.ribbonButton54.AltKey = null;
            this.ribbonButton54.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton54.Image = global::RibbonDemo.Properties.Resources.capitalletter32;
            this.ribbonButton54.SmallImage = global::RibbonDemo.Properties.Resources.capitalletter16;
            this.ribbonButton54.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton54.Tag = null;
            this.ribbonButton54.Text = "Capital letter";
            this.ribbonButton54.ToolTip = null;
            this.ribbonButton54.ToolTipImage = null;
            this.ribbonButton54.ToolTipTitle = null;
            // 
            // ribbonButton55
            // 
            this.ribbonButton55.AltKey = null;
            this.ribbonButton55.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton55.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton55.Image")));
            this.ribbonButton55.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton55.SmallImage = global::RibbonDemo.Properties.Resources.signatureline16;
            this.ribbonButton55.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton55.Tag = null;
            this.ribbonButton55.Text = "Signature line";
            this.ribbonButton55.ToolTip = null;
            this.ribbonButton55.ToolTipImage = null;
            this.ribbonButton55.ToolTipTitle = null;
            // 
            // ribbonButton56
            // 
            this.ribbonButton56.AltKey = null;
            this.ribbonButton56.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton56.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton56.Image")));
            this.ribbonButton56.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton56.SmallImage = global::RibbonDemo.Properties.Resources.datetime16;
            this.ribbonButton56.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton56.Tag = null;
            this.ribbonButton56.Text = "Date and time";
            this.ribbonButton56.ToolTip = null;
            this.ribbonButton56.ToolTipImage = null;
            this.ribbonButton56.ToolTipTitle = null;
            // 
            // ribbonButton57
            // 
            this.ribbonButton57.AltKey = null;
            this.ribbonButton57.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton57.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton57.Image")));
            this.ribbonButton57.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButton57.SmallImage = global::RibbonDemo.Properties.Resources.insertobject16;
            this.ribbonButton57.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton57.Tag = null;
            this.ribbonButton57.Text = "Insert object";
            this.ribbonButton57.ToolTip = null;
            this.ribbonButton57.ToolTipImage = null;
            this.ribbonButton57.ToolTipTitle = null;
            // 
            // ribbonPanel12
            // 
            this.ribbonPanel12.ButtonMoreEnabled = false;
            this.ribbonPanel12.ButtonMoreVisible = false;
            this.ribbonPanel12.Image = global::RibbonDemo.Properties.Resources.symbol16;
            this.ribbonPanel12.Items.Add(this.ribbonButton35);
            this.ribbonPanel12.Items.Add(this.ribbonButton36);
            this.ribbonPanel12.Tag = null;
            this.ribbonPanel12.Text = "Symbols";
            // 
            // ribbonButton35
            // 
            this.ribbonButton35.AltKey = null;
            this.ribbonButton35.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton35.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton35.Image")));
            this.ribbonButton35.SmallImage = global::RibbonDemo.Properties.Resources.formula16;
            this.ribbonButton35.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonButton35.Tag = null;
            this.ribbonButton35.Text = "Formula";
            this.ribbonButton35.ToolTip = null;
            this.ribbonButton35.ToolTipImage = null;
            this.ribbonButton35.ToolTipTitle = null;
            // 
            // ribbonButton36
            // 
            this.ribbonButton36.AltKey = null;
            this.ribbonButton36.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton36.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton36.Image")));
            this.ribbonButton36.SmallImage = global::RibbonDemo.Properties.Resources.symbol16;
            this.ribbonButton36.Style = System.Windows.Forms.RibbonButtonStyle.DropDown;
            this.ribbonButton36.Tag = null;
            this.ribbonButton36.Text = "Symbol";
            this.ribbonButton36.ToolTip = null;
            this.ribbonButton36.ToolTipImage = null;
            this.ribbonButton36.ToolTipTitle = null;
            // 
            // ribbonTab3
            // 
            this.ribbonTab3.Panels.Add(this.ribbonPanel13);
            this.ribbonTab3.Panels.Add(this.ribbonPanel14);
            this.ribbonTab3.Tag = null;
            this.ribbonTab3.Text = "TextBoxes";
            // 
            // ribbonPanel13
            // 
            this.ribbonPanel13.ButtonMoreVisible = false;
            this.ribbonPanel13.Image = global::RibbonDemo.Properties.Resources.link16;
            this.ribbonPanel13.Items.Add(this.ribbonTextBox2);
            this.ribbonPanel13.Items.Add(this.ribbonSeparator6);
            this.ribbonPanel13.Items.Add(this.ribbonTextBox3);
            this.ribbonPanel13.Items.Add(this.ribbonTextBox4);
            this.ribbonPanel13.Tag = null;
            this.ribbonPanel13.Text = "With image and label";
            // 
            // ribbonTextBox2
            // 
            this.ribbonTextBox2.AltKey = null;
            this.ribbonTextBox2.Image = global::RibbonDemo.Properties.Resources.link16;
            this.ribbonTextBox2.Tag = null;
            this.ribbonTextBox2.Text = "Link:";
            this.ribbonTextBox2.TextBoxText = "http://www.google.com";
            this.ribbonTextBox2.TextBoxWidth = 150;
            this.ribbonTextBox2.ToolTip = null;
            this.ribbonTextBox2.ToolTipImage = null;
            this.ribbonTextBox2.ToolTipTitle = null;
            // 
            // ribbonSeparator6
            // 
            this.ribbonSeparator6.AltKey = null;
            this.ribbonSeparator6.Image = null;
            this.ribbonSeparator6.Tag = null;
            this.ribbonSeparator6.Text = null;
            this.ribbonSeparator6.ToolTip = null;
            this.ribbonSeparator6.ToolTipImage = null;
            this.ribbonSeparator6.ToolTipTitle = null;
            // 
            // ribbonTextBox3
            // 
            this.ribbonTextBox3.AltKey = null;
            this.ribbonTextBox3.Image = global::RibbonDemo.Properties.Resources.style16;
            this.ribbonTextBox3.Tag = null;
            this.ribbonTextBox3.Text = "Style name:";
            this.ribbonTextBox3.TextBoxText = null;
            this.ribbonTextBox3.ToolTip = null;
            this.ribbonTextBox3.ToolTipImage = null;
            this.ribbonTextBox3.ToolTipTitle = null;
            // 
            // ribbonTextBox4
            // 
            this.ribbonTextBox4.AltKey = null;
            this.ribbonTextBox4.Image = global::RibbonDemo.Properties.Resources.replace16;
            this.ribbonTextBox4.Tag = null;
            this.ribbonTextBox4.Text = "Replace word:";
            this.ribbonTextBox4.TextBoxText = null;
            this.ribbonTextBox4.ToolTip = null;
            this.ribbonTextBox4.ToolTipImage = null;
            this.ribbonTextBox4.ToolTipTitle = null;
            // 
            // ribbonPanel14
            // 
            this.ribbonPanel14.Image = global::RibbonDemo.Properties.Resources.alignleft16;
            this.ribbonPanel14.Items.Add(this.ribbonTextBox5);
            this.ribbonPanel14.Items.Add(this.ribbonComboBox1);
            this.ribbonPanel14.Tag = null;
            this.ribbonPanel14.Text = "Just image";
            // 
            // ribbonTextBox5
            // 
            this.ribbonTextBox5.AltKey = null;
            this.ribbonTextBox5.Image = global::RibbonDemo.Properties.Resources.arrangeup16;
            this.ribbonTextBox5.Tag = null;
            this.ribbonTextBox5.Text = null;
            this.ribbonTextBox5.TextBoxText = null;
            this.ribbonTextBox5.ToolTip = null;
            this.ribbonTextBox5.ToolTipImage = null;
            this.ribbonTextBox5.ToolTipTitle = null;
            // 
            // ribbonComboBox1
            // 
            this.ribbonComboBox1.AltKey = null;
            this.ribbonComboBox1.DropDownItems.Add(this.ribbonButton91);
            this.ribbonComboBox1.DropDownItems.Add(this.ribbonButton92);
            this.ribbonComboBox1.DropDownItems.Add(this.ribbonButton93);
            this.ribbonComboBox1.DropDownResizable = true;
            this.ribbonComboBox1.Image = global::RibbonDemo.Properties.Resources.chart16;
            this.ribbonComboBox1.Tag = null;
            this.ribbonComboBox1.Text = null;
            this.ribbonComboBox1.TextBoxText = null;
            this.ribbonComboBox1.ToolTip = null;
            this.ribbonComboBox1.ToolTipImage = null;
            this.ribbonComboBox1.ToolTipTitle = null;
            // 
            // ribbonButton91
            // 
            this.ribbonButton91.AltKey = null;
            this.ribbonButton91.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton91.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton91.Image")));
            this.ribbonButton91.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton91.SmallImage")));
            this.ribbonButton91.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton91.Tag = null;
            this.ribbonButton91.Text = "ribbonButton91";
            this.ribbonButton91.ToolTip = null;
            this.ribbonButton91.ToolTipImage = null;
            this.ribbonButton91.ToolTipTitle = null;
            // 
            // ribbonButton92
            // 
            this.ribbonButton92.AltKey = null;
            this.ribbonButton92.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton92.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton92.Image")));
            this.ribbonButton92.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton92.SmallImage")));
            this.ribbonButton92.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton92.Tag = null;
            this.ribbonButton92.Text = "ribbonButton92";
            this.ribbonButton92.ToolTip = null;
            this.ribbonButton92.ToolTipImage = null;
            this.ribbonButton92.ToolTipTitle = null;
            // 
            // ribbonButton93
            // 
            this.ribbonButton93.AltKey = null;
            this.ribbonButton93.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton93.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton93.Image")));
            this.ribbonButton93.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton93.SmallImage")));
            this.ribbonButton93.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton93.Tag = null;
            this.ribbonButton93.Text = "ribbonButton93";
            this.ribbonButton93.ToolTip = null;
            this.ribbonButton93.ToolTipImage = null;
            this.ribbonButton93.ToolTipTitle = null;
            // 
            // ribbonButton69
            // 
            this.ribbonButton69.AltKey = null;
            this.ribbonButton69.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton69.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton69.Image")));
            this.ribbonButton69.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton69.SmallImage")));
            this.ribbonButton69.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton69.Tag = null;
            this.ribbonButton69.Text = "ribbonButton69";
            this.ribbonButton69.ToolTip = null;
            this.ribbonButton69.ToolTipImage = null;
            this.ribbonButton69.ToolTipTitle = null;
            // 
            // ribbonButton68
            // 
            this.ribbonButton68.AltKey = null;
            this.ribbonButton68.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton68.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton68.Image")));
            this.ribbonButton68.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton68.SmallImage")));
            this.ribbonButton68.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton68.Tag = null;
            this.ribbonButton68.Text = "ribbonButton68";
            this.ribbonButton68.ToolTip = null;
            this.ribbonButton68.ToolTipImage = null;
            this.ribbonButton68.ToolTipTitle = null;
            // 
            // ribbonButton67
            // 
            this.ribbonButton67.AltKey = null;
            this.ribbonButton67.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton67.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton67.Image")));
            this.ribbonButton67.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton67.SmallImage")));
            this.ribbonButton67.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton67.Tag = null;
            this.ribbonButton67.Text = "ribbonButton67";
            this.ribbonButton67.ToolTip = null;
            this.ribbonButton67.ToolTipImage = null;
            this.ribbonButton67.ToolTipTitle = null;
            // 
            // ribbonButton66
            // 
            this.ribbonButton66.AltKey = null;
            this.ribbonButton66.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton66.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton66.Image")));
            this.ribbonButton66.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton66.SmallImage")));
            this.ribbonButton66.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton66.Tag = null;
            this.ribbonButton66.Text = "ribbonButton66";
            this.ribbonButton66.ToolTip = null;
            this.ribbonButton66.ToolTipImage = null;
            this.ribbonButton66.ToolTipTitle = null;
            // 
            // ribbonButton65
            // 
            this.ribbonButton65.AltKey = null;
            this.ribbonButton65.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton65.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton65.Image")));
            this.ribbonButton65.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton65.SmallImage")));
            this.ribbonButton65.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton65.Tag = null;
            this.ribbonButton65.Text = "ribbonButton65";
            this.ribbonButton65.ToolTip = null;
            this.ribbonButton65.ToolTipImage = null;
            this.ribbonButton65.ToolTipTitle = null;
            // 
            // ribbonButton64
            // 
            this.ribbonButton64.AltKey = null;
            this.ribbonButton64.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton64.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton64.Image")));
            this.ribbonButton64.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton64.SmallImage")));
            this.ribbonButton64.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton64.Tag = null;
            this.ribbonButton64.Text = "ribbonButton64";
            this.ribbonButton64.ToolTip = null;
            this.ribbonButton64.ToolTipImage = null;
            this.ribbonButton64.ToolTipTitle = null;
            // 
            // ribbonButton63
            // 
            this.ribbonButton63.AltKey = null;
            this.ribbonButton63.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton63.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton63.Image")));
            this.ribbonButton63.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton63.SmallImage")));
            this.ribbonButton63.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton63.Tag = null;
            this.ribbonButton63.Text = "ribbonButton63";
            this.ribbonButton63.ToolTip = null;
            this.ribbonButton63.ToolTipImage = null;
            this.ribbonButton63.ToolTipTitle = null;
            // 
            // ribbonButton62
            // 
            this.ribbonButton62.AltKey = null;
            this.ribbonButton62.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton62.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton62.Image")));
            this.ribbonButton62.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton62.SmallImage")));
            this.ribbonButton62.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton62.Tag = null;
            this.ribbonButton62.Text = "ribbonButton62";
            this.ribbonButton62.ToolTip = null;
            this.ribbonButton62.ToolTipImage = null;
            this.ribbonButton62.ToolTipTitle = null;
            // 
            // ribbonButton61
            // 
            this.ribbonButton61.AltKey = null;
            this.ribbonButton61.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton61.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton61.Image")));
            this.ribbonButton61.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton61.SmallImage")));
            this.ribbonButton61.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton61.Tag = null;
            this.ribbonButton61.Text = "ribbonButton61";
            this.ribbonButton61.ToolTip = null;
            this.ribbonButton61.ToolTipImage = null;
            this.ribbonButton61.ToolTipTitle = null;
            // 
            // ribbonButton60
            // 
            this.ribbonButton60.AltKey = null;
            this.ribbonButton60.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton60.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton60.Image")));
            this.ribbonButton60.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton60.SmallImage")));
            this.ribbonButton60.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton60.Tag = null;
            this.ribbonButton60.Text = "ribbonButton60";
            this.ribbonButton60.ToolTip = null;
            this.ribbonButton60.ToolTipImage = null;
            this.ribbonButton60.ToolTipTitle = null;
            // 
            // ribbonButton59
            // 
            this.ribbonButton59.AltKey = null;
            this.ribbonButton59.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton59.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton59.Image")));
            this.ribbonButton59.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton59.SmallImage")));
            this.ribbonButton59.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton59.Tag = null;
            this.ribbonButton59.Text = "ribbonButton59";
            this.ribbonButton59.ToolTip = null;
            this.ribbonButton59.ToolTipImage = null;
            this.ribbonButton59.ToolTipTitle = null;
            // 
            // ribbonButton58
            // 
            this.ribbonButton58.AltKey = null;
            this.ribbonButton58.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton58.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton58.Image")));
            this.ribbonButton58.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton58.SmallImage")));
            this.ribbonButton58.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton58.Tag = null;
            this.ribbonButton58.Text = "ribbonButton58";
            this.ribbonButton58.ToolTip = null;
            this.ribbonButton58.ToolTipImage = null;
            this.ribbonButton58.ToolTipTitle = null;
            // 
            // ribbonButtonList1
            // 
            this.ribbonButtonList1.AltKey = null;
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton58);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton59);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton60);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton61);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton62);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton63);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton64);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton65);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton66);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton67);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton68);
            this.ribbonButtonList1.Buttons.Add(this.ribbonButton69);
            this.ribbonButtonList1.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonList1.Image = null;
            this.ribbonButtonList1.ItemsSizeInDropwDownMode = new System.Drawing.Size(7, 5);
            this.ribbonButtonList1.Tag = null;
            this.ribbonButtonList1.Text = "ribbonButtonList1";
            this.ribbonButtonList1.ToolTip = null;
            this.ribbonButtonList1.ToolTipImage = null;
            this.ribbonButtonList1.ToolTipTitle = null;
            // 
            // ribbonButton88
            // 
            this.ribbonButton88.AltKey = null;
            this.ribbonButton88.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton88.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton88.Image")));
            this.ribbonButton88.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton88.SmallImage")));
            this.ribbonButton88.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton88.Tag = null;
            this.ribbonButton88.Text = "ribbonButton88";
            this.ribbonButton88.ToolTip = null;
            this.ribbonButton88.ToolTipImage = null;
            this.ribbonButton88.ToolTipTitle = null;
            // 
            // ribbonButton89
            // 
            this.ribbonButton89.AltKey = null;
            this.ribbonButton89.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton89.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton89.Image")));
            this.ribbonButton89.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton89.SmallImage")));
            this.ribbonButton89.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton89.Tag = null;
            this.ribbonButton89.Text = "ribbonButton89";
            this.ribbonButton89.ToolTip = null;
            this.ribbonButton89.ToolTipImage = null;
            this.ribbonButton89.ToolTipTitle = null;
            // 
            // ribbonButton90
            // 
            this.ribbonButton90.AltKey = null;
            this.ribbonButton90.DropDownArrowSize = new System.Drawing.Size(5, 3);
            this.ribbonButton90.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton90.Image")));
            this.ribbonButton90.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton90.SmallImage")));
            this.ribbonButton90.Style = System.Windows.Forms.RibbonButtonStyle.Normal;
            this.ribbonButton90.Tag = null;
            this.ribbonButton90.Text = "ribbonButton90";
            this.ribbonButton90.ToolTip = null;
            this.ribbonButton90.ToolTipImage = null;
            this.ribbonButton90.ToolTipTitle = null;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(796, 386);
            this.Controls.Add(this.ribbon1);
            this.Name = "MainForm";
            this.Text = "Ribbon Demo";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Ribbon ribbon1;
        private System.Windows.Forms.RibbonTab ribbonTab1;
        private System.Windows.Forms.RibbonTab ribbonTab2;
        private System.Windows.Forms.RibbonPanel ribbonPanel1;
        private System.Windows.Forms.RibbonButton ribbonButton1;
        private System.Windows.Forms.RibbonButton ribbonButton2;
        private System.Windows.Forms.RibbonButton ribbonButton3;
        private System.Windows.Forms.RibbonButton ribbonButton4;
        private System.Windows.Forms.RibbonPanel ribbonPanel2;
        private System.Windows.Forms.RibbonPanel ribbonPanel3;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup1;
        private System.Windows.Forms.RibbonButton ribbonButton5;
        private System.Windows.Forms.RibbonButton ribbonButton6;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup2;
        private System.Windows.Forms.RibbonButton ribbonButton7;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup3;
        private System.Windows.Forms.RibbonButton ribbonButton8;
        private System.Windows.Forms.RibbonButton ribbonButton9;
        private System.Windows.Forms.RibbonButton ribbonButton10;
        private System.Windows.Forms.RibbonButton ribbonButton14;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup4;
        private System.Windows.Forms.RibbonButton ribbonButton11;
        private System.Windows.Forms.RibbonButton ribbonButton12;
        private System.Windows.Forms.RibbonButton ribbonButton13;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup5;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup6;
        private System.Windows.Forms.RibbonButton ribbonButton17;
        private System.Windows.Forms.RibbonButton ribbonButton18;
        private System.Windows.Forms.RibbonButton ribbonButton19;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup7;
        private System.Windows.Forms.RibbonButton ribbonButton20;
        private System.Windows.Forms.RibbonButton ribbonButton21;
        private System.Windows.Forms.RibbonButton ribbonButton22;
        private System.Windows.Forms.RibbonButton ribbonButton23;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup8;
        private System.Windows.Forms.RibbonButton ribbonButton24;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup9;
        private System.Windows.Forms.RibbonButton ribbonButton25;
        private System.Windows.Forms.RibbonButton ribbonButton26;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup10;
        private System.Windows.Forms.RibbonButton ribbonButton27;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup11;
        private System.Windows.Forms.RibbonButton ribbonButton28;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup12;
        private System.Windows.Forms.RibbonButton ribbonButton29;
        private System.Windows.Forms.RibbonButton ribbonButton30;
        private System.Windows.Forms.RibbonPanel ribbonPanel4;
        private System.Windows.Forms.RibbonPanel ribbonPanel5;
        private System.Windows.Forms.RibbonButton ribbonButton31;
        private System.Windows.Forms.RibbonButton ribbonButton32;
        private System.Windows.Forms.RibbonButton ribbonButton33;
        private System.Windows.Forms.RibbonPanel ribbonPanel6;
        private System.Windows.Forms.RibbonPanel ribbonPanel7;
        private System.Windows.Forms.RibbonPanel ribbonPanel8;
        private System.Windows.Forms.RibbonPanel ribbonPanel9;
        private System.Windows.Forms.RibbonPanel ribbonPanel10;
        private System.Windows.Forms.RibbonPanel ribbonPanel11;
        private System.Windows.Forms.RibbonPanel ribbonPanel12;
        private System.Windows.Forms.RibbonButton ribbonButton35;
        private System.Windows.Forms.RibbonButton ribbonButton36;
        private System.Windows.Forms.RibbonButton ribbonButton37;
        private System.Windows.Forms.RibbonButton ribbonButton38;
        private System.Windows.Forms.RibbonButton ribbonButton39;
        private System.Windows.Forms.RibbonButton ribbonButton40;
        private System.Windows.Forms.RibbonButton ribbonButton41;
        private System.Windows.Forms.RibbonButton ribbonButton42;
        private System.Windows.Forms.RibbonButton ribbonButton43;
        private System.Windows.Forms.RibbonButton ribbonButton44;
        private System.Windows.Forms.RibbonButton ribbonButton45;
        private System.Windows.Forms.RibbonButton ribbonButton46;
        private System.Windows.Forms.RibbonButton ribbonButton47;
        private System.Windows.Forms.RibbonButton ribbonButton48;
        private System.Windows.Forms.RibbonButton ribbonButton49;
        private System.Windows.Forms.RibbonButton ribbonButton50;
        private System.Windows.Forms.RibbonButton ribbonButton51;
        private System.Windows.Forms.RibbonButton ribbonButton52;
        private System.Windows.Forms.RibbonButton ribbonButton53;
        private System.Windows.Forms.RibbonButton ribbonButton54;
        private System.Windows.Forms.RibbonButton ribbonButton55;
        private System.Windows.Forms.RibbonButton ribbonButton56;
        private System.Windows.Forms.RibbonButton ribbonButton57;
        private System.Windows.Forms.RibbonButton ribbonButton70;
        private System.Windows.Forms.RibbonButton ribbonButton71;
        private System.Windows.Forms.RibbonButton ribbonButton72;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator1;
        private System.Windows.Forms.RibbonButton ribbonButton73;
        private System.Windows.Forms.RibbonButton ribbonButton74;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator2;
        private System.Windows.Forms.RibbonButton ribbonButton75;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator3;
        private System.Windows.Forms.RibbonButton ribbonButton76;
        private System.Windows.Forms.RibbonButton ribbonButton77;
        private System.Windows.Forms.RibbonButton ribbonButton78;
        private System.Windows.Forms.RibbonButton ribbonButton79;
        private System.Windows.Forms.RibbonButton ribbonButton69;
        private System.Windows.Forms.RibbonButton ribbonButton68;
        private System.Windows.Forms.RibbonButton ribbonButton67;
        private System.Windows.Forms.RibbonButton ribbonButton66;
        private System.Windows.Forms.RibbonButton ribbonButton65;
        private System.Windows.Forms.RibbonButton ribbonButton64;
        private System.Windows.Forms.RibbonButton ribbonButton63;
        private System.Windows.Forms.RibbonButton ribbonButton62;
        private System.Windows.Forms.RibbonButton ribbonButton61;
        private System.Windows.Forms.RibbonButton ribbonButton60;
        private System.Windows.Forms.RibbonButton ribbonButton59;
        private System.Windows.Forms.RibbonButton ribbonButton58;
        private System.Windows.Forms.RibbonButtonList ribbonButtonList1;
        private System.Windows.Forms.RibbonButtonList lst;
        private System.Windows.Forms.RibbonButton ribbonButton34;
        private System.Windows.Forms.RibbonButton ribbonButton80;
        private System.Windows.Forms.RibbonButton ribbonButton81;
        private System.Windows.Forms.RibbonButton ribbonButton82;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator4;
        private System.Windows.Forms.RibbonButton ribbonButton83;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator5;
        private System.Windows.Forms.RibbonButton ribbonButton84;
        private System.Windows.Forms.RibbonButton ribbonButton85;
        private System.Windows.Forms.RibbonButton ribbonButton86;
        private System.Windows.Forms.RibbonButton ribbonButton87;
        private System.Windows.Forms.RibbonTab ribbonTab3;
        private System.Windows.Forms.RibbonPanel ribbonPanel13;
        private System.Windows.Forms.RibbonTextBox ribbonTextBox2;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator6;
        private System.Windows.Forms.RibbonTextBox ribbonTextBox3;
        private System.Windows.Forms.RibbonTextBox ribbonTextBox4;
        private System.Windows.Forms.RibbonPanel ribbonPanel14;
        private System.Windows.Forms.RibbonTextBox ribbonTextBox5;
        private System.Windows.Forms.RibbonComboBox ribbonComboBox1;
        private System.Windows.Forms.RibbonButton ribbonButton88;
        private System.Windows.Forms.RibbonButton ribbonButton89;
        private System.Windows.Forms.RibbonButton ribbonButton90;
        private System.Windows.Forms.RibbonButton ribbonButton91;
        private System.Windows.Forms.RibbonButton ribbonButton92;
        private System.Windows.Forms.RibbonButton ribbonButton93;
        private System.Windows.Forms.RibbonColorChooser ribbonColorChooser1;
        private System.Windows.Forms.RibbonColorChooser ribbonColorChooser2;
        private System.Windows.Forms.RibbonItemGroup ribbonItemGroup13;
        private System.Windows.Forms.RibbonComboBox ribbonComboBox2;
        private System.Windows.Forms.RibbonComboBox ribbonComboBox3;
        private System.Windows.Forms.RibbonButton ribbonButton15;
        private System.Windows.Forms.RibbonButton ribbonButton16;
        private System.Windows.Forms.RibbonButton ribbonButton94;
        private System.Windows.Forms.RibbonButton ribbonButton95;
        private System.Windows.Forms.RibbonButton ribbonButton96;
        private System.Windows.Forms.RibbonButton ribbonButton97;
        private System.Windows.Forms.RibbonButton ribbonButton98;
        private System.Windows.Forms.RibbonButton ribbonButton99;
        private System.Windows.Forms.RibbonButton ribbonButton100;
        private System.Windows.Forms.RibbonButton ribbonButton101;
        private System.Windows.Forms.RibbonButton ribbonButton102;
        private System.Windows.Forms.RibbonButton ribbonButton103;
        private System.Windows.Forms.RibbonButton ribbonButton104;
        private System.Windows.Forms.RibbonButton ribbonButton105;
        private System.Windows.Forms.RibbonButton ribbonButton106;
        private System.Windows.Forms.RibbonButton ribbonButton107;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator7;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator8;
    }
}