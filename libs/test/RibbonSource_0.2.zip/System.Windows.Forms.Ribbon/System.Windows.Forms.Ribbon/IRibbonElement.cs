/*
 
 2008 Jos� Manuel Men�ndez Poo
 * 
 * Please give me credit if you use this code. It's all I ask.
 * 
 * Contact me for more info: menendezpoo@gmail.com
 * 
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace System.Windows.Forms
{
    /// <summary>
    /// Interface that every drawable ribbon element must implement
    /// </summary>
    public interface IRibbonElement
    {
        /// <summary>
        /// Called on every element when its time to draw itself
        /// </summary>
        /// <param name="g">Device to draw</param>
        /// <param name="sender">Object that is invoking the paint element</param>
        /// <param name="e">Paint event data</param>
        void OnPaint(Object sender, RibbonElementPaintEventArgs e);

        /// <summary>
        /// Gets the size in pixels needed for the element in the specified mode
        /// </summary>
        /// <param name="sender">Object that sends the measure message</param>
        /// <param name="e">Event data</param>
        Size MeasureSize(object sender, RibbonElementMeasureSizeEventArgs e);

        /// <summary>
        /// Called to make the element aware of its actual bounds on the control
        /// </summary>
        void SetBounds(System.Drawing.Rectangle bounds);

        /// <summary>
        /// Gets the bounds of the item
        /// </summary>
        Rectangle Bounds { get;}
    }
}
